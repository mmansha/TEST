CREATE TABLE `city_tier` (
  `CityTier` varchar(25) NOT NULL,
  `Description` varchar(512) NOT NULL,
  PRIMARY KEY (`CityTier`)
);
